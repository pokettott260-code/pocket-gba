# Pocket GBA — mGBA WebAssembly PWA

iPhone Safari向けの個人用プロトタイプです。ネイティブiOSアプリ（IPA）ではなく、Safariで開きホーム画面に追加するWebアプリです。

## 注意
- mGBAコアは `@wasm-gaming/mgba-wasm` を利用します。これは公式mGBAのiOSアプリではなく、コミュニティによるWebAssemblyビルドです。
- このスターターはプロトタイプです。iOS Safariでの完全な動作検証はまだ行っていません。WASMアセットの読み込みやタッチ入力は、公開後に確認・調整が必要になる場合があります。
- ROMは自分で合法的に入手したファイルを使用してください。著作権のあるゲームROMやBIOSはこのプロジェクトに含めていません。
- mGBAはMPL-2.0ライセンスです。依存パッケージやソースを改変・再配布する場合は各ライセンスを確認してください。

## iPhoneだけで公開する想定手順（GitHub Pages）
このリポジトリはGitHub Actionsでクラウド上ビルドし、GitHub Pagesに公開する構成です。Macは不要ですが、GitHubアカウントとインターネット接続が必要です。

1. GitHubで新しい空のリポジトリを作成（例: `pocket-gba`）。
2. ZIPを展開したファイル一式をリポジトリのルートにアップロード。`.github/workflows/deploy.yml` も含めます。
   - iPhoneだけでZIPを展開・複数ファイルをアップロードするのが難しい場合、GitHub Codespacesを使ってクラウド上でZIPを展開する方法があります。Codespacesの利用可否・料金枠はアカウントにより異なります。
3. リポジトリの **Settings → Pages → Build and deployment** で **GitHub Actions** を選択。
4. **Actions** タブで `Build and deploy Pocket GBA` が成功するのを待つ。
5. Settings → Pages に表示されるURLをSafariで開く。
6. Safariの共有ボタン → **ホーム画面に追加**。ホーム画面から起動できます。

## ローカル開発（Mac/Linux/PCが使える場合）
```sh
npm install
npm run dev
```

本番ビルド:
```sh
npm run build
```

## 操作
- ROMを選択：Filesから `.gba`, `.gb`, `.gbc`, `.zip` を選択
- 十字キー、A/B、L/R、START/SELECT：画面上のボタンを長押し
- iOS Safariでは音声を有効にするため、最初の操作後に再生が始まる場合があります

## 使用技術
- Vite
- `@wasm-gaming/mgba-wasm`
- PWA / Service Worker
- Canvas / Pointer Events
