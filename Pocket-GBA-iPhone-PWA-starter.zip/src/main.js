import { load } from '@wasm-gaming/mgba-wasm';

const canvas = document.querySelector('#game-canvas');
const fileInput = document.querySelector('#rom-file');
const statusEl = document.querySelector('#status');
const messageEl = document.querySelector('#message');
const placeholder = document.querySelector('#screen-placeholder');
const pauseButton = document.querySelector('#pause-button');

let engine = null;
let paused = false;
const held = new Set();

function status(text) { statusEl.textContent = text; }
function message(text) { messageEl.textContent = text; }

async function stopEngine() {
  if (!engine) return;
  try {
    if (typeof engine.pause === 'function') engine.pause();
    if (typeof engine.destroy === 'function') await engine.destroy();
  } catch (error) {
    console.warn('Engine cleanup:', error);
  }
  engine = null;
}

fileInput.addEventListener('change', async () => {
  const file = fileInput.files?.[0];
  if (!file) return;
  await stopEngine();
  status('読み込み中');
  message(`読み込み中: ${file.name}`);
  pauseButton.disabled = true;
  try {
    const rom = new Uint8Array(await file.arrayBuffer());
    engine = await load({
      canvasEl: canvas,
      assets: { rom },
      options: { system: 'auto', aspect: 'native', renderFilter: 'pixelated' },
      persist: 'opfs',
      storageNamespace: 'pocket-gba',
      onEvent: (event) => console.log('[mGBA]', event)
    });
    engine.start();
    paused = false;
    pauseButton.textContent = '一時停止';
    pauseButton.disabled = false;
    placeholder.hidden = true;
    status('プレイ中');
    message(`${file.name} を読み込みました。画面をタップしてから操作してください。`);
  } catch (error) {
    console.error(error);
    status('エラー');
    message('ROMを起動できませんでした。mGBA WebAssemblyの読み込み、ROM形式、ブラウザ対応を確認してください。詳細は開発者コンソールを確認してください。');
  }
});

pauseButton.addEventListener('click', () => {
  if (!engine) return;
  try {
    if (!paused && typeof engine.pause === 'function') engine.pause();
    else if (paused && typeof engine.start === 'function') engine.start();
    paused = !paused;
    pauseButton.textContent = paused ? '再開' : '一時停止';
    status(paused ? '一時停止中' : 'プレイ中');
  } catch (error) {
    console.error(error);
    message('一時停止の切り替えに失敗しました。');
  }
});

// The mGBA WASM SDK maps these keyboard codes to the standard GBA controls.
// Pointer events keep buttons responsive on touchscreens and avoid stuck keys.
function press(key) {
  if (held.has(key)) return;
  held.add(key);
  window.dispatchEvent(new KeyboardEvent('keydown', { key, code: key, bubbles: true }));
}
function release(key) {
  if (!held.has(key)) return;
  held.delete(key);
  window.dispatchEvent(new KeyboardEvent('keyup', { key, code: key, bubbles: true }));
}

document.querySelectorAll('[data-key]').forEach((button) => {
  const key = button.dataset.key;
  button.addEventListener('pointerdown', (event) => {
    event.preventDefault();
    button.setPointerCapture?.(event.pointerId);
    press(key);
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture', 'pointerleave']) {
    button.addEventListener(type, () => release(key));
  }
  button.addEventListener('contextmenu', (event) => event.preventDefault());
});

window.addEventListener('blur', () => {
  for (const key of [...held]) release(key);
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden) for (const key of [...held]) release(key);
});

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch((error) => console.warn('SW registration failed:', error));
  });
}
